module SIsudoku {
	requires qqwing;
}