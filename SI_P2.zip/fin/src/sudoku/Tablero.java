package sudoku;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;



public class Tablero {
	private List<List<Integer>> tablero; // Lista de filas del sudoku contiene los ceros donde no hay valores
	private List<List<Integer>> individuop; // Individuo primigenio el primer individuo del que sacaremos la poblacion(No se modifica)

	public Tablero(int[] t) {
		tablero = new ArrayList<>();
		individuop = new ArrayList<>();
		int aux = 0;
		for (int f = 0; f < 9; f++) {
			List<Integer> valores = new ArrayList<>(Arrays.asList(1,2,3,4,5,6,7,8,9));
			List<Integer> fila = new ArrayList<>();
			for (int c = 0; c < 9; c++) {
				fila.add(t[aux]);
				valores.remove(Integer.valueOf(t[aux]));
				aux++;
			}
			tablero.add(fila);
			individuop.add(valores);
		}
	}

	public List<List<Integer>> getTablero() {
		return tablero;
	}
	
	public List<List<Integer>> getIndividuop() {
		return individuop;
	}

	
	//Convierte el tablero a una lista de columnas
	public List<List<Integer>> getColumnas(List<List<Integer>> t){
		List<List<Integer>> columnas = new ArrayList<>();
		for (int i = 0; i < 9 ; i++) {
			List<Integer> columna = new ArrayList<>();
			for(int j = 0; j < 9; j++) {
				columna.add(t.get(j).get(i));
			}
			columnas.add(columna);
		}
		return columnas;
	}
	
	// Imprime las filas
	public List<List<Integer>> getFilas(){
		return getTablero();
	}
	
	// Convierte el tablero en una lista con los bloques
	public List<List<Integer>> getBloques(List<List<Integer>> t){
		List<List<Integer>> bloques = new ArrayList<>();		
		for (int i = 0; i < 9; i += 3) {
		    for (int j = 0; j < 9; j += 3) {
		        List<Integer> bloque = new ArrayList<>();
		        for (int k = i; k < i + 3; k++) {
		            for (int l = j; l < j + 3; l++) {
		                bloque.add(t.get(k).get(l));
		            }
		        }
		        bloques.add(bloque);
		    }
		}
		 return bloques;
	}
	
	//devuelve el tablero relleno con el individuo individuo
	public List<List<Integer>> rellenar(List<List<Integer>> individuo) {
		List<List<Integer>> t = clonar(getTablero());
		List<List<Integer>> gen = clonar(individuo);
		
		//System.out.println(gen);
		for(int i = 0 ; i < tablero.size();i++) {
			int aux = 0;
			while(t.get(i).indexOf(0)>=0) {
				List<Integer> tabla = t.get(i);
				tabla.set(tabla.indexOf(0), Integer.valueOf(gen.get(i).get(aux)));
				aux ++;
			}
		}
		return t;
	}
	
	//Clona las listas de listas
	private List<List<Integer>> clonar(List<List<Integer>> l){
		List<List<Integer>> aux = new ArrayList<>();
		for(List<Integer> a : l) {
			List<Integer> nueva = new ArrayList<>(a);
			aux.add(nueva);
		}
		return aux;
	}

	
	/* private List<List<List<Integer>>> clonarb(List<List<List<Integer>>> l){
		List<List<List<Integer>>> aux = new ArrayList<>();
		for(List<List<Integer>> a : l) {
			List<List<Integer>> nueva = clonar(a);
			aux.add(nueva);
		}
		return aux;
	}*/
	
	//Genera la poblacion con n individuos
	public List<List<List<Integer>>> genPoblacion(int n){
		List<List<List<Integer>>> poblacion = new ArrayList<>();
		for(int i = 0; i < n;i++) {
			poblacion.add(genIndividuo());
		}
		return poblacion;
	}
	
	//Genera un individuo mezclando aleatoriamente al individuoprimigenio
	public List<List<Integer>> genIndividuo() {
		List<List<Integer>> individuo = new ArrayList<>();
		List<List<Integer>> individuop = clonar(getIndividuop());
		Random r = new Random();
		for(int i = 0 ; i < 9; i++) {
			List<Integer> fila = new ArrayList<>();
			while(!individuop.get(i).isEmpty()) {
				int aleatorio = r.nextInt(individuop.get(i).size());
				fila.add(individuop.get(i).get(aleatorio));
				individuop.get(i).remove(aleatorio);
			}
			individuo.add(fila);
		}
		return individuo;
	}
	
	//Apartir de un individuo te dice el fitness que tiene
	public int getFitness(List<List<Integer>> individuo) {
	 int fit = 0;
	 List<List<Integer>> t = rellenar(individuo);
	 Set<Integer> rescol = new HashSet<>();
	 Set<Integer> colt = new HashSet<>();
	 Set<Integer> resblo = new HashSet<>();
	 Set<Integer> blot = new HashSet<>();
	 for(List<Integer> columna : getColumnas(t)) {
		 rescol.clear();
			colt.clear();
		 for(Integer i : columna) {
			 if(rescol.contains(i)) {
				 colt.add(i);
			 } else {
				 rescol.add(i);
			 }
		 }
		 rescol.removeAll(colt);
		 fit  = fit + rescol.size();
	 }
	 for(List<Integer> bloque : getBloques(t)) {
		 resblo.clear();
		 blot.clear();
		 for(Integer i : bloque) {
			 if(resblo.contains(i)) {
				 blot.add(i);
			 } else {
				 resblo.add(i);
			 }
		 }
		 resblo.removeAll(blot);
		 fit  = fit + resblo.size();
		 
	 }
     return fit;
	}
	
	
	//Función que selecciona dos elementos de la poblacion dando mas probabilidad a los elementos con mayor fitness 
	  public int[] seleccionarElementos(List<List<List<Integer>>> lista, List<Integer> pesos) {
	        int[] elementosSeleccionados = new int[2];
	        // Generar un número aleatorio ponderado para seleccionar el primer elemento de la lista
	        double sumaPesos = 0;
	        for (double peso : pesos) {
	            sumaPesos +=peso;
	        }
	        Random rand = new Random();
	        double numeroAleatorio1 = rand.nextInt() * sumaPesos;
	        double sumaParcial = 0;
	        int indiceSeleccionado1 = 0;
	        for (int i = 0; i < lista.size(); i++) {
	            sumaParcial += pesos.get(i);
	            if (sumaParcial >= numeroAleatorio1) {
	                indiceSeleccionado1 = i;
	                break;
	            }
	        }
	        elementosSeleccionados[0] = indiceSeleccionado1;

	        // Generar un número aleatorio ponderado para seleccionar el segundo elemento de la lista
	        sumaPesos -= pesos.get(indiceSeleccionado1);
	        double numeroAleatorio2 = rand.nextDouble() * sumaPesos;
	        sumaParcial = 0;
	        int indiceSeleccionado2 = 0;
	        for (int i = 0; i < lista.size(); i++) {
	            if (i == indiceSeleccionado1) {
	                continue; // Saltar el elemento seleccionado previamente
	            }
	            sumaParcial +=   pesos.get(i);
	            if (sumaParcial >= numeroAleatorio2) {
	                indiceSeleccionado2 = i;
	                break;
	            }
	        }
	        elementosSeleccionados[1] = indiceSeleccionado2;
	        if(elementosSeleccionados[0] > elementosSeleccionados[1]) {
	        	int aux = elementosSeleccionados[1];
	        	elementosSeleccionados[1]=elementosSeleccionados[0];
	        	elementosSeleccionados[0]=aux;
	        }
	        return elementosSeleccionados;
	    }
	



	/*public List<List<Integer>> resultado(int n){
		Integer fitness = 0;
		List<List<Integer>> mejor = new ArrayList<>();
		List<List<List<Integer>>> poblacion = genPoblacion(n);
		List<Integer> pesos = new ArrayList<>();// lista de pesos de la poblacion
		
		
		poblacion.sort(Comparator.comparingInt(inidivid -> -getFitness(inidivid)));
		for(List<List<Integer>> individuo : poblacion) {
			pesos.add(getFitness(individuo));
		}
		
		List<List<List<Integer>>>poblacion2 = new ArrayList<>();
		Random r = new Random();
		do {
			// genero la poblacion
			poblacion2 = clonarb(poblacion);
			// poblacion vacia
			
			while(poblacion.size()>=2) {
				List<List<Integer>> hijo = new ArrayList<>();
				int numa = r.nextInt(poblacion.size());
				int numb = r.nextInt(poblacion.size());
				while(numa == numb) {
					numb = r.nextInt(poblacion.size());
				}
				int[] padres= seleccionarElementos(poblacion, pesos);
				hijo = clonar(reproduce(poblacion.get(padres[0]), poblacion.get(padres[1])));
				if (Math.random() < 0.4) {
					  hijo = clonar(mutate(hijo));
					}
				poblacion2.add(hijo);
					poblacion.remove(padres[1]);
					poblacion.remove(padres[0]);	
			}
			poblacion.clear();
			poblacion= clonarb(poblacion2);
			poblacion.sort(Comparator.comparingInt(inidivid -> -getFitness(inidivid)));
			poblacion2.clear();
			pesos.clear();// lista de pesos de la poblacion
			fitness = 0;
			for(List<List<Integer>> individuo : poblacion) {
				pesos.add(getFitness(individuo));
			}
			fitness = getFitness(poblacion.get(0));
			System.out.println(fitness);
			mejor = poblacion.get(0);
			//System.out.println(fitness);
			//System.out.println(mejor);
			
			//recorre la poblacion elige dos individuos aleatorios y los reproduce
			
			//hay una problabilidad de que el hijo mute
			//añadimos el hijo a la nueva poblacion
			//devolvemos el mejor individuo de la poblacion
			
			
			
		} while (fitness < 162);
		return mejor;
	}
	*/
	 
	  //itera hasta encontrar el resultado o hasta que itere 'maximo' veces
	public List<List<Integer>> resultado(int n , int maximo){
		Integer fitness = 0;
		double contador = 0.1;
		List<List<Integer>> mejor = new ArrayList<>(); // El mejor individuo de cada iteración
		List<List<List<Integer>>> poblacion = genPoblacion(n); // Lista poblacion
		List<Integer> pesos = new ArrayList<>();// lista de pesos de la poblacion
		System.out.println(poblacion.toString());
		
		poblacion.sort(Comparator.comparingInt(inidivid -> -getFitness(inidivid)));	//Ordena la poblacion segun el fitness
		
		for(List<List<Integer>> individuo : poblacion) {
			pesos.add(getFitness(individuo));
		} //Rellenamos la lista de pesos con los pesos de la poblacion
		
		// Padre literalmente
		// hijo
		// mutaciones de ambos
		
		
		
		
		Set<List<List<Integer>>> poblacion2 = new HashSet<>(); 
		do {
			// genero la poblacion
			// poblacion vacia
			
			while(poblacion2.size() < n) {
				List<List<Integer>> hijo = new ArrayList<>();
				int[] padres= seleccionarElementos(poblacion, pesos);
				if (Math.random() < 0.5) {
					  hijo = poblacion.get(padres[0]);
					  //poblacion.remove(padres[0]);
				} else {
					hijo = clonar(reproduce(poblacion.get(padres[0]), poblacion.get(padres[1])));
					//poblacion.remove(padres[1]);
					//poblacion.remove(padres[0]);
				}
				if (Math.random() < 0.3) {
					  hijo = clonar(mutate(hijo));
					}
				poblacion2.add(hijo);
					
				}
			/*if(poblacion.size()==1) {
				poblacion2.add(poblacion.get(0));
				poblacion.remove(0);
				
			}*/
			poblacion.clear();
			poblacion.addAll(poblacion2);
			poblacion.sort(Comparator.comparingInt(inidivid -> -getFitness(inidivid)));
			poblacion2.clear();
			
			pesos.clear();// lista de pesos de la poblacion
			fitness = 0;
			for(List<List<Integer>> individuo : poblacion) {
				pesos.add(getFitness(individuo));
			}
			fitness = getFitness(poblacion.get(0));
			mejor = poblacion.get(0);
			System.out.println("La media es: "+suma(pesos)/pesos.size());
			System.out.println(fitness);
			//System.out.println(fitness);
			//System.out.println(mejor);
			
			//recorre la poblacion elige dos individuos aleatorios y los reproduce
			
			//hay una problabilidad de que el hijo mute
			//añadimos el hijo a la nueva poblacion
			//devolvemos el mejor individuo de la poblacion
			
			maximo =maximo-1;
			
		} while (fitness < 162 && 0 < maximo);
		return mejor;
	}
	
	
	//Guarda en un fichero el mejor individuo
	public void afichero(int a, int b) {
		List<List<Integer>> res = this.resultado(a,b);
		boolean encontrado = getFitness(res) == 162;		
		try {
			PrintWriter pw = new PrintWriter("output.txt", "UTF-8");
			if(!encontrado) {
				pw.println("Sudoku no resuelto");
			}
			pw.println("Mejor individuo: "+ res);
			pw.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//Suma los elementos de una lista
	public int suma(List<Integer> lista) {
		int suma = 0;
		for(Integer n : lista) {
			suma = suma + n;
		}
		return suma;
	}
	
	  //MEJORRRRRRRR
	  /*public List<List<Integer>> resultado(int n){
		Integer fitness = 0;
		double contador = 0.1;
		int sum = 0;
		List<List<Integer>> mejor = new ArrayList<>();
		List<List<List<Integer>>> poblacion = genPoblacion(n);
		List<Integer> pesos = new ArrayList<>();// lista de pesos de la poblacion
		poblacion.sort(Comparator.comparingInt(inidivid -> -getFitness(inidivid)));	
		for(List<List<Integer>> individuo : poblacion) {
			pesos.add(getFitness(individuo));
		}
		Set<List<List<Integer>>> poblacion2 = new HashSet<>();
		poblacion2.addAll(poblacion);
		Random r = new Random();
		do {
			// genero la poblacion
			poblacion2.addAll(poblacion);
			// poblacion vacia
			
			while(poblacion.size()>=2) {
				List<List<Integer>> hijo = new ArrayList<>();
				int numa = r.nextInt(poblacion.size());
				int numb = r.nextInt(poblacion.size());
				while(numa == numb) {
					numb = r.nextInt(poblacion.size());
				}
				hijo = clonar(reproduce(poblacion.get(numa), poblacion.get(numb)));
				if (Math.random() <0.2) {
					  hijo = clonar(mutate(hijo));
					}
				poblacion2.add(hijo);
				if(numa < numb) {
					poblacion.remove(numa);
					poblacion.remove(numb-1);
				} else {
					poblacion.remove(numa);
					poblacion.remove(numb);
				}				
			}
			poblacion.clear();
			poblacion.addAll(poblacion2);
			poblacion.sort(Comparator.comparingInt(inidivid -> -getFitness(inidivid)));
			poblacion.subList(n+sum, poblacion2.size()).clear();
			sum++;
			poblacion2.clear();
			pesos.clear();// lista de pesos de la poblacion
			fitness = 0;
			for(List<List<Integer>> individuo : poblacion) {
				pesos.add(getFitness(individuo));
			}
			fitness = getFitness(poblacion.get(0));
			System.out.println(pesos);
			System.out.println(fitness);
			mejor = poblacion.get(0);
			//System.out.println(fitness);
			//System.out.println(mejor);
			//recorre la poblacion elige dos individuos aleatorios y los reproduce
			
			//hay una problabilidad de que el hijo mute
			//añadimos el hijo a la nueva poblacion
			//devolvemos el mejor individuo de la poblacion
			
			
		} while (fitness < 162);
		return mejor;
	}*/
	

	/*public Individuo genetic(itness) {
		repeat
		weights := WEIGHTED-BY(population,fitness)
		population2 := empty list
		for i=1

		to SIZE(population) do
		parent1, parent2 := WEIGHTED-RANDOM-CHOICES(population,weights,2)
		child := REPRODUCE(parent1, parent2)
		if (small random probability) then child := MUTATE(child)
		add child to population2
		population := population2
		until some individual is fit enough, or enough time has elapsed
		return the best individual in population, according to fitness

		function REPRODUCE(parent1, parent2) returns an individual
		n := LENGTH(parent1)
		c := random number from 1 to n
		return APPEND(SUBSTRING(parent1,1,c), SUBSTRING(parent2,c+1,n))
		
		
	}*/
	
	//De dos padres genera un individuo hijo, junta aleatoriamente una parte padreA a padre B nunca puede devolver a un padre
	public List<List<Integer>> reproduce(List<List<Integer>> a, List<List<Integer>> b){
		List<List<Integer>> hijo = new ArrayList<>();
		Random r = new Random();
		int num = r.nextInt(a.size()-2)+1;
		for(int i  = 0 ; i < num; i ++) {
			hijo.add(a.get(i));
		}
		for(int i  = num ; i < 9; i ++) {
			hijo.add(b.get(i));
		}
		return hijo;
	}
	
	//Hace una mutacion del individuo
	public List<List<Integer>> mutate(List<List<Integer>> a){
		List<List<Integer>> mutado = clonar(a);
		for(List<Integer> fila : mutado) {
			if(fila.size() >= 2) {
				Random r = new Random();
				int num = r.nextInt(fila.size());
				int num2 = r.nextInt(fila.size());
				int aux1 = fila.get(num);
				fila.set(num, fila.get(num2));
				fila.set(num2, aux1);
			}
			/*if(fila.size() >= 4) {
				Random r = new Random();
				int num = r.nextInt(fila.size());
				int num2 = r.nextInt(fila.size());
				int aux1 = fila.get(num);
				fila.set(num, fila.get(num2));
				fila.set(num2, aux1);
			}*/
		}
		return mutado;
	}

	@Override
	public String toString() {
		return tablero.toString()+"\n"+individuop.toString()+"\n";
	}

}
