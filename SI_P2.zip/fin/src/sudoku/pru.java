package sudoku;

import java.util.Arrays;

import com.qqwing.Difficulty;

public class pru {

	public static void main(String[] args) {
		int option = 1;
		//int option = 2;
		//int option = 3;
		//int option = 4;
		//int option = 5;
        int []puzzle = null;
        switch (option) {
        case 1:
            //Extremely easy puzzle, should be solvable without tuning the parameters of the genetic algorithm
            puzzle = EjemploQQWing.computePuzzleWithNHolesPerRow(3);
            break;
        case 2:
            //Puzzle with difficulty SIMPLE as assessed by QQWing.
            //Should require just minimal tuning of the parameters of the genetic algorithm
            puzzle = EjemploQQWing.computePuzzleByDifficulty(Difficulty.SIMPLE);
            break;
        case 3:
            //Puzzle with difficulty EASY as assessed by QQWing.
            //Should require some tuning of the parameters of the genetic algorithm
            puzzle = EjemploQQWing.computePuzzleByDifficulty(Difficulty.EASY);
            break;
        case 4:
            //Puzzle with difficulty INTERMEDIATE as assessed by QQWing.
            //Should require serious effort tuning the parameters of the genetic algorithm
            puzzle = EjemploQQWing.computePuzzleByDifficulty(Difficulty.INTERMEDIATE);
            break;
        case 5:
            //Puzzle with difficulty EXPERT as assessed by QQWing.
            //Should require great effort tuning the parameters of the genetic algorithm
            puzzle = EjemploQQWing.computePuzzleByDifficulty(Difficulty.EXPERT);
            break;
        }
        
        System.out.print(Arrays.toString(puzzle));
	

	}

}
