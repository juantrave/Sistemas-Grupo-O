package laberinto;

public class Estudio {
	 
}
