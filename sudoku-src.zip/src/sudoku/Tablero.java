package sudoku;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import javax.print.attribute.SetOfIntegerSyntax;

public class Tablero {
	private List<List<Integer>> tablero;
	private List<List<Integer>> individuop;

	public Tablero(int[] t) {
		tablero = new ArrayList<>();
		individuop = new ArrayList<>();
		int aux = 0;
		for (int f = 0; f < 9; f++) {
			List<Integer> valores = new ArrayList<>(Arrays.asList(1,2,3,4,5,6,7,8,9));
			List<Integer> fila = new ArrayList<>();
			for (int c = 0; c < 9; c++) {
				fila.add(t[aux]);
				valores.remove(Integer.valueOf(t[aux]));
				aux++;
			}
			tablero.add(fila);
			individuop.add(valores);
		}
	}
	
	public Tablero(List<List<Integer>> t) {
		tablero = t;
	}	

	public List<List<Integer>> getTablero() {
		return tablero;
	}
	
	public List<List<Integer>> getIndividuop() {
		return individuop;
	}

	public List<List<Integer>> getColumnas(){
		List<List<Integer>> columnas = new ArrayList<>();
		for (int i = 0; i < 9 ; i++) {
			List<Integer> columna = new ArrayList<>();
			for(int j = 0; j < 9; j++) {
				columna.add(tablero.get(j).get(i));
			}
			columnas.add(columna);
		}
		return columnas;
	}
	
	public List<List<Integer>> getFilas(){
		return getTablero();
	}
	
	public List<List<Integer>> getBloques(){
		List<List<Integer>> bloques = new ArrayList<>();		
		for (int i = 0; i < 9; i += 3) {
		    for (int j = 0; j < 9; j += 3) {
		        List<Integer> bloque = new ArrayList<>();
		        for (int k = i; k < i + 3; k++) {
		            for (int l = j; l < j + 3; l++) {
		                bloque.add(tablero.get(k).get(l));
		            }
		        }
		        bloques.add(bloque);
		    }
		}
		 return bloques;
	}
	
	public List<List<Integer>> rellenar(List<List<Integer>> individuo) {
		List<List<Integer>> t = new ArrayList<>(getTablero());
		List<List<Integer>> gen = new ArrayList<>(individuo);
		for(int i = 0 ; i < tablero.size();i++) {
			int aux = 0;
			while(t.get(i).indexOf(0)>=0) {
				List<Integer> tabla = t.get(i);
				tabla.set(tabla.indexOf(0), Integer.valueOf(gen.get(i).get(aux)));
				aux ++;
			}
		}
		return t;
	}
	
	private List<List<Integer>> clonar(List<List<Integer>> l){
		List<List<Integer>> aux = new ArrayList<>();
		for(List<Integer> a : l) {
			List<Integer> nueva = new ArrayList<>(a);
			aux.add(nueva);
		}
		return aux;
	}
	
	public List<List<List<Integer>>> genPoblacion(int n){
		List<List<List<Integer>>> poblacion = new ArrayList<>();
		
		for(int i = 0; i < n;i++) {
			poblacion.add(genIndividuo());
		}
		return poblacion;
	}
	
	public List<List<Integer>> genIndividuo() {
		List<List<Integer>> individuo = new ArrayList<>();
		List<List<Integer>> individuop = clonar(getIndividuop());
		Random r = new Random();
		for(int i = 0 ; i < 9; i++) {
			List<Integer> fila = new ArrayList<>();
			while(!individuop.get(i).isEmpty()) {
				int aleatorio = r.nextInt(individuop.get(i).size());
				fila.add(individuop.get(i).get(aleatorio));
				individuop.get(i).remove(aleatorio);
			}
			individuo.add(fila);
		}
		return individuo;
	}
	
	public int getFitness(List<List<Integer>> individuo) {
	 int fit = 0;
	 Tablero t = new Tablero(rellenar(individuo));
	 Set<Integer> rescol = new HashSet<>();
	 Set<Integer> resblo = new HashSet<>();
	 for(List<Integer> columna : t.getColumnas()) {
		 for(Integer i : columna) {
			 rescol.add(i);
		 }
		 fit  = fit + rescol.size();
	 }
	 for(List<Integer> bloque : t.getBloques()) {
		 for(Integer i : bloque) {
			 resblo.add(i);
		 }
		 fit  = fit + resblo.size();
	 }
	 
     return fit;
	}



	public List<List<Integer>> resultado(int n){
		int fitness = 0;
		int contador = 0;
		do {
			List<List<List<Integer>>> poblacion = new ArrayList<>();// genero la poblacion
			List<Integer> pesos = new ArrayList<>();
			for(List<List<Integer>> individuo : poblacion) {
				pesos.add(getFitness(individuo));
			}
			// lista de pesos de la poblacion
			// poblacion vacia
			
			//recorre la poblacion elige dos individuos aleatorios y los reproduce
			//hay una problabilidad de que el hijo mute
			//añadimos el hijo a la nueva poblacion
			//devolvemos el mejor individuo de la poblacion
			
			
			contador ++;
		} while (fitness < 162 || contador < 500);
	}

	/*public Individuo genetic(itness) {
		repeat
		weights := WEIGHTED-BY(population,fitness)
		population2 := empty list
		for i=1

		to SIZE(population) do
		parent1, parent2 := WEIGHTED-RANDOM-CHOICES(population,weights,2)
		child := REPRODUCE(parent1, parent2)
		if (small random probability) then child := MUTATE(child)
		add child to population2
		population := population2
		until some individual is fit enough, or enough time has elapsed
		return the best individual in population, according to fitness

		function REPRODUCE(parent1, parent2) returns an individual
		n := LENGTH(parent1)
		c := random number from 1 to n
		return APPEND(SUBSTRING(parent1,1,c), SUBSTRING(parent2,c+1,n))
		
		
	}*/
	
	public List<List<Integer>> reproduce(List<List<Integer>> a, List<List<Integer>> b){
		List<List<Integer>> hijo = new ArrayList<>();
		Random r = new Random();
		int num = r.nextInt(a.size()-2)+1;
		for(int i  = 0 ; i < num; i ++) {
			hijo.add(a.get(i));
		}
		for(int i  = num ; i < 9; i ++) {
			hijo.add(b.get(i));
		}
		return hijo;
	}
	
	public List<List<Integer>> mutate(List<List<Integer>> a){
		List<List<Integer>> mutado = clonar(a);
		for(List<Integer> fila : mutado) {
			if(fila.size() >= 2) {
				Random r = new Random();
				int num = r.nextInt(fila.size());
				int num2 = r.nextInt(fila.size());
				int aux1 = fila.get(num);
				fila.set(num, fila.get(num2));
				fila.set(num2, aux1);
			}
		}
		return mutado;
	}

	@Override
	public String toString() {
		return tablero.toString()+"\n"+individuop.toString()+"\n";
	}

}
