package sudoku;

import java.util.List;

public class prueba {
	public static void main(String[] args) {
		int[] a= {5,0,4,6,0,8,9,1,2,
				6,0,0,1,9,0,3,0,8,
				1,9,0,0,0,0,0,0,7,
				8,0,0,7,0,1,0,0,3,
				4,0,6,8,5,0,7,0,1,
				7,0,0,9,0,0,0,0,6,
				9,0,0,0,0,7,0,8,4,
				2,0,0,0,0,9,6,0,5,
				3,0,0,0,0,6,1,0,9};
		
		int[] b = {5,3,4,6,7,8,9,1,2,
				6,7,2,1,9,5,3,4,8,
				1,9,8,3,4,2,5,6,7,
				8,5,9,7,6,1,4,2,3,
				4,2,6,8,5,3,7,9,1,
				7,1,3,9,2,4,8,5,6,
				9,6,1,5,3,7,2,8,4,
				2,8,7,4,1,9,6,3,5,
				3,4,5,2,8,6,1,7,9};
		Tablero t = new Tablero(a);
		Tablero res = new Tablero(b);
		
		List<List<Integer>> individuo = t.genIndividuo();
		List<List<Integer>> individuo2 = t.genIndividuo();
		
		System.out.println("No-Resuelto");
		System.out.println(t);
		System.out.println("Resuelto");
		System.out.println(res);
		System.out.println(t.getBloques());
		System.out.println("Individuos");
		System.out.println(individuo2.toString());
		System.out.println(individuo.toString());
		System.out.println("Mutacion");
		System.out.println(t.mutate(individuo));
		System.out.println("Reproduce");
		System.out.println(t.reproduce(individuo, individuo2));
		System.out.println(t.rellenar(individuo));
		System.out.println(t.getFitness(individuo));
		
		
		/*{5,3,4,6,7,8,9,1,2,
			6,7,2,1,9,5,3,4,8,
			1,9,8,3,4,2,5,6,7,
			8,5,9,7,6,1,4,2,3,
			4,2,6,8,5,3,7,9,1,
			7,1,3,9,2,4,8,5,6,
			9,6,1,5,3,7,2,8,4,
			2,8,7,4,1,9,6,3,5,
			3,4,5,2,8,6,1,7,9}*/
		
		//System.out.print(i.toString());
		//System.out.print(t);
		/*System.out.print(t.getBloques().toString());
		System.out.println(t.rellenar(i));*/
		
	}
}
