package sudoku;

import java.util.List;

import com.qqwing.Difficulty;

public class prueba {
	public static void main(String[] args) {
		int[] a= {5,0,4,6,0,8,0,1,0,
				6,0,0,1,9,0,3,0,8,
				1,9,0,3,4,0,0,0,7,
				8,0,0,7,0,1,0,0,3,
				4,0,6,8,5,0,7,0,1,
				7,1,0,9,0,4,0,0,6,
				9,0,1,0,0,7,0,8,4,
				2,0,7,0,0,9,6,0,5,
				3,0,0,0,0,6,1,0,9};
		
		int[] b = {5,3,4,6,7,8,9,1,2,
				6,7,2,1,9,5,3,4,8,
				1,9,8,3,4,2,5,6,7,
				8,5,9,7,6,1,4,2,3,
				4,2,6,8,5,3,7,9,1,
				7,1,3,9,2,4,8,5,6,
				9,6,1,5,3,7,2,8,4,
				2,8,7,4,1,9,6,3,5,
				3,4,5,2,8,6,1,7,9};
		Tablero t = new Tablero(sudoku(1));
		Tablero res = new Tablero(b);
		List<List<Integer>> individuo = t.genIndividuo();
		List<List<Integer>> individuo2 = t.genIndividuo();
		
		/*System.out.println("No-Resuelto");
		System.out.println(t);
		System.out.println("Resuelto");
		System.out.println(res.getFitness(individuo));
		System.out.println("-------------------");*/
		System.out.println(t);
		System.out.println(t.getBloques(t.getTablero()));
		System.out.println(t.getColumnas(t.rellenar(individuo2)));
		System.out.println(t.getFitness(individuo2));
		System.out.println(t.rellenar(t.resultado(1000,500)).toString());
		//t.afichero(100, 800);
		
		
		
		/*{5,3,4,6,7,8,9,1,2,
			6,7,2,1,9,5,3,4,8,
			1,9,8,3,4,2,5,6,7,
			8,5,9,7,6,1,4,2,3,
			4,2,6,8,5,3,7,9,1,
			7,1,3,9,2,4,8,5,6,
			9,6,1,5,3,7,2,8,4,
			2,8,7,4,1,9,6,3,5,
			3,4,5,2,8,6,1,7,9}
		//System.out.print(i.toString());
		//System.out.print(t);
		/*System.out.print(t.getBloques().toString());
		System.out.println(t.rellenar(i));*/
				
		
	}
	public static int[] sudoku(int i) {
		 int []puzzle = null;
	        switch (i) {
	        case 1:
	            //Extremely easy puzzle, should be solvable without tuning the parameters of the genetic algorithm
	            puzzle = EjemploQQWing.computePuzzleWithNHolesPerRow(3);
	            break;
	        case 2:
	            //Puzzle with difficulty SIMPLE as assessed by QQWing.
	            //Should require just minimal tuning of the parameters of the genetic algorithm
	            puzzle = EjemploQQWing.computePuzzleByDifficulty(Difficulty.SIMPLE);
	            break;
	        case 3:
	            //Puzzle with difficulty EASY as assessed by QQWing.
	            //Should require some tuning of the parameters of the genetic algorithm
	            puzzle = EjemploQQWing.computePuzzleByDifficulty(Difficulty.EASY);
	            break;
	        case 4:
	            //Puzzle with difficulty INTERMEDIATE as assessed by QQWing.
	            //Should require serious effort tuning the parameters of the genetic algorithm
	            puzzle = EjemploQQWing.computePuzzleByDifficulty(Difficulty.INTERMEDIATE);
	            break;
	        case 5:
	            //Puzzle with difficulty EXPERT as assessed by QQWing.
	            //Should require great effort tuning the parameters of the genetic algorithm
	            puzzle = EjemploQQWing.computePuzzleByDifficulty(Difficulty.EXPERT);
	            break;
	        }
	        return puzzle;
	}

}
